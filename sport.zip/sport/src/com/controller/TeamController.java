package com.controller;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.frame.Biz;
import com.vo.Team;

@Controller
public class TeamController {

	@Resource(name = "tbiz")
	Biz<Integer, Team> biz;

	@RequestMapping("allteam.mc")
	public ModelAndView allteam() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Team> list = null;
		try {
			list = biz.get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		mv.addObject("tlist", list);
		mv.setViewName("contact");
		return mv;
	}

}
