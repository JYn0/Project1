package com.controller;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.frame.Biz;
import com.vo.Player;

@Controller
public class PlayerController {
	
	@Resource(name ="plbiz")
	Biz<Integer, Player> biz;
	
	@RequestMapping("playerlist.mc")
	public ModelAndView playerlist(String id) {
		String uid = id;
		ModelAndView mv = new ModelAndView();
		if(uid.equals("1")) {
			mv.setViewName("kt-inform");
		}
		else if(uid.equals("2")) {	
			mv.setViewName("lg-inform");
		}
			
		ArrayList<Player> list = null;
		
		try {
			list = biz.get();
		} catch (Exception e) {		
			e.printStackTrace();
		}
		
		mv.addObject("playerlist", list);
		return mv;
	}
	
	@RequestMapping("allplayerlist.mc")
	public ModelAndView allplayerlist() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Player> list = null;
		try {
			list = biz.get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		mv.addObject("playerlist",list);
		mv.setViewName("contact");
		return mv;
	}

}
