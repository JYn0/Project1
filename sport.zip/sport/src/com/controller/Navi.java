package com.controller;

public class Navi {
	public static String home = "<a href='main.do'>HOME</a>";
	public static String login = home + " > Login";
	public static String register = home + " > Register";
	public static String aboutus = home + " > About Us";
	public static String useradd = home + " > User > Add";
	public static String userlist = home + " > User > List";
	public static String userdetail = home + " > User > List > Detail";
	public static String productadd = home + " > Product > Add";
	public static String productlist = home + " > Product > List";
	public static String productdetail = home + " > Product > List > Detail";

}
